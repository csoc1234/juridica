<?php
header('Location: web');
$yii=dirname(__FILE__).'/var/www/html/personerias/yii.php';
?>
