use wadeshuler\jwplayer\JWPlayer;

<?= JWPlayer::widget([
    'playerOptions' => [
        'file' => '/web/video/1.webm'
    ]
]) ?>
