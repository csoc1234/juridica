<?php

return [
    'adminEmail' => 'sistemas.gobvalle@gmail.com',
	'user.passwordResetTokenExpire' => 3600,
	'supportEmail' => 'sistemas.gobvalle@gmail.com',
	/*'components' => [
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'useFileTransport' => false,//set this property to false to send mails to real email addresses
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.gmail.com',
                'username' => 'admon.aecindi@gmail.com',
                'password' => 'aecindi34',
                'port' => '587',
                'encryption' => 'tls',
            ],
        ],
    ],*/
];
