<?php

return [

    'class' => 'yii\db\Connection',

    'dsn' => 'mysql:host=localhost;dbname=personerias;',

    //'dsn' => 'mysql:host=localhost:3307;dbname=personerias;',

    'username' => 'personerias',
    'password' => 'personerias2019',
    'charset' =>  'utf8',
   
    /*
    'class' => 'yii\db\Connection',
    //'dsn' => 'mysql:host=localhost;dbname=personerias;',
    'dsn' => 'mysql:host=localhost:3307;dbname=personerias;',
    'username' => 'root',
    'password' => '',
    'charset' =>  'utf8', */
];
?>
