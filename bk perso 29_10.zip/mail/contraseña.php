<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user app\models\User */

?>
<div class="correo-reget">
  <div><div class="adM">
  </div><table width="600" border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#ffffff">
    <tbody><tr align="center">
      <td style="vertical-align:top" colspan="3">
  		<font color="#ffffff">.</font><br>
  	  <center><img src="http://www.valledelcauca.gov.co/info/base2016/imagenes/logoGobernacion.png"></center>
      </td>
    </tr>
    <tr>
      <td width="600" bgcolor="#F2F3F7">
      	<table width="600" border="0" cellpadding="0" cellspacing="0">
  	  		<tbody>
  	  			<tr>
  					<td ></td>
  					<td >
  						<p style="font-family:arial,helvetica,verdana;font-weight:normal;font-size:32px;line-height:1.2;color:#00a8df;display:block;text-align:left;margin:0;padding:0;text-align:center">Alerta de seguridad</p>
  					</td>
  					</tr>
  			</tbody>
  		</table>
      </td>
    </tr>
    <br>
    <tr>
      <table width="600" border="0" cellpadding="0" cellspacing="10" align="center">
        	  		<tbody>
        	  		 <tr>
        					<td>
                    <span style="font-family:arial,helvetica,verdana;font-weight:normal;font-size:14px;
                    line-height:1.2;color:#50525a;display:block;margin:0;padding:0;text-align:justify">
                    Estimado/a  <?php echo $nombres." ".$apellido1." ".$apellido2; ?>
                    usted ha designado como nueva contraseña <i><strong><?php echo $password ?></strong></i>, en caso de no haber sido usted quien
                    realizo el cambio de la contraseña, por favor comuníquese con la secretaria TIC.</span>
                  </td>
        				</tr>
        			</tbody>
      </table>
    </tr>
    <br>
    <tr align="center">
      <table align="center" width="560" border="0" cellpadding="10" cellspacing="2" bgcolor="#87888C">
            <tbody align="center">
              <tr align="center">
                <td align="center">
				  					<span style="font-family:arial,helvetica,verdana;font-weight:normal;font-size:14px;line-height:1.2;color:#ffffff;display:block;margin:0;padding:0;text-align:justify">
				  					Este envío es confidencial y está destinado únicamente a la persona a la que ha sido enviado. Puede contener información privada y confidencial. Si usted no es el destinatario al que ha sido remitida, no puede copiarla, distribuirla ni emprender con ella ningún tipo de acción. Si cree que lo ha recibido por error, por favor, notifíquelo al remitente.
					  				</span>
					  			</td>
				  			</tr>
						</tbody>
      </table>
    </tr>
    <br>
    <tr align="center">
      <td width="560">
      	<table width="560" border="0" cellpadding="0" cellspacing="10" align="center">
  	  		<tbody>


  	  			<tr>
  					<td><p style="font-family:arial,helvetica,verdana;font-weight:normal;font-size:18px;line-height:1.2;color:#00a8df;display:block;margin:0;padding:0;text-align:justify">PD: Antes de imprimir este e-mail piense bien si es necesario hacerlo. El medio ambiente es cosa de todos.</p></td>
  	  			</tr>
  			</tbody>
  		</table>
      </td>
    </tr>
    <tr align="center">
    	<td width="600">

      </td>
    </tr>

    <tr align="center">
    	<td>
    		<br>
    		<p style="font-family:arial,helvetica,verdana;font-weight:bold;font-size:17px;line-height:1.2;color:#50525a;display:block;text-align:center;margin:0;padding:0"></p><br>
    		<p style="font-family:arial,helvetica,verdana;font-weight:normal;font-size:14px;line-height:1.2;color:#50525a;display:block;text-align:center;margin:0;padding:0"><strong><span class="il">Gobernación del Valle del Cauca, Santiago de Cali - Colombia</span></strong> </p>
    	</td>
    </tr>
  </tbody></table>
  <div class="yj6qo">
  </div>
  <div class="adL">
  </div>
</div>

</div>
