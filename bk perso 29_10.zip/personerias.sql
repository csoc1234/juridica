Terminal close -- exit!
